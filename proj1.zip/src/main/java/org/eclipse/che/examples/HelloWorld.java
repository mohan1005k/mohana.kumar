package org.eclipse.che.examples;

 class HelloWorld {
    public static void main(String[] argvs) {
        String a = "Cheee";
        System.out.println("Hello Worldss " + a + "!");
    }
}
